
import { Link } from "react-router-dom";

function Navbar() {
    return (
        <nav className="navbar">
            <div className="navbar-container">

                <Link to="/" className="logo">
                    Blog App Using Usestate
                </Link>

                <div className="nav-links">

                    <Link to="/">
                        Home
                    </Link>

                    <Link to="/create">
                        Create Blog
                    </Link>

                </div>

            </div>
        </nav>
    );
}

export default Navbar;
