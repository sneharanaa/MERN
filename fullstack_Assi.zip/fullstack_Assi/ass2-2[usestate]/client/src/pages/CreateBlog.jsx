
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../service/api";

function CreateBlog() {
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        title: "",
        content: ""
    });

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    // Handle input changes
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    // Create blog
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.title.trim() || !formData.content.trim()) {
            setError("Please enter both title and content");
            return;
        }

        setError("");

        try {
            setLoading(true);

            await API.post("/blogs", {
                title: formData.title,
                content: formData.content
            });

            alert("Blog created successfully");

            setFormData({
                title: "",
                content: ""
            });

            navigate("/");
        } catch (error) {
            setError(
                error.response?.data?.message ||
                "Failed to create blog"
            );
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="form-container">
            <div className="form-box blog-form">
                <h1>Create Blog</h1>

                {error && (
                    <p className="error">{error}</p>
                )}

                <form onSubmit={handleSubmit}>
                    <label>Blog Title</label>

                    <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="Enter blog title"
                        required
                    />

                    <label>Blog Content</label>

                    <textarea
                        name="content"
                        value={formData.content}
                        onChange={handleChange}
                        placeholder="Write your blog..."
                        rows="10"
                        required
                    />

                    <button
                        type="submit"
                        disabled={loading}
                    >
                        {loading ? "Publishing..." : "Publish Blog"}
                    </button>
                </form>
            </div>
        </div>
    );
}

export default CreateBlog;
