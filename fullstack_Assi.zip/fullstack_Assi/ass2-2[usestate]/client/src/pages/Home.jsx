import { useEffect, useState } from "react";
import API from "../service/api";
import BlogCard from "../component/BlogCard";

function Home() {

  const [blogs, setBlogs] = useState([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");

  useEffect(() => {
    fetchBlogs();
  }, []);

  const fetchBlogs = async () => {
    try {
      setLoading(true);

      const response = await API.get("/blogs");

      setBlogs(response.data);

      setError("");
    } catch (error) {
      console.log(error);

      setError("Failed to load blogs");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">

      <div className="home-header">
        <h1>All Blogs</h1>
      </div>

      {loading && (
        <p className="message">
          Loading blogs...
        </p>
      )}

      {error && (
        <p className="error">
          {error}
        </p>
      )}

      {!loading && blogs.length === 0 && (
        <p className="message">
          No blogs available.
        </p>
      )}

      <div className="blog-grid">

        {blogs.map((blog) => (
          <BlogCard
            key={blog._id}
            blog={blog}
          />
        ))}

      </div>

    </div>
  );
}

export default Home;