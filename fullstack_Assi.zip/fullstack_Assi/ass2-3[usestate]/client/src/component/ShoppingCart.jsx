
import React, { useEffect, useState } from "react";
import API from "../service/app";

function ShoppingCart() {
    const [products, setProducts] = useState([]);
    const [cart, setCart] = useState([]);
    const [search, setSearch] = useState("");

    const getProducts = async () => {
        try {
            const res = await API.get("/products");
            setProducts(res.data);
        } catch (error) {
            console.log(error);
            alert("Error loading products. Check your server.");
        }
    };

    useEffect(() => {
        getProducts();
    }, []);

    const addToCart = (product) => {
        const exists = cart.find((item) => item._id === product._id);

        if (exists) {
            setCart(cart.map((item) =>
                item._id === product._id
                    ? { ...item, qty: item.qty + 1 }
                    : item
            ));
        } else {
            setCart([...cart, { ...product, qty: 1 }]);
        }
    };

    const increaseQty = (id) => {
        setCart(cart.map((item) =>
            item._id === id
                ? { ...item, qty: item.qty + 1 }
                : item
        ));
    };

    const decreaseQty = (id) => {
        setCart(cart.map((item) =>
            item._id === id
                ? { ...item, qty: item.qty - 1 }
                : item
        ).filter((item) => item.qty > 0));
    };

    const removeItem = (id) => {
        setCart(cart.filter((item) => item._id !== id));
    };

    const total = cart.reduce(
        (sum, item) => sum + item.price * item.qty,
        0
    );

    const filteredProducts = products.filter((product) =>
        product.name?.toLowerCase().includes(search.toLowerCase()) ||
        product.category?.toLowerCase().includes(search.toLowerCase()) ||
        product.brand?.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="container">
            <h1>Shopping Cart using Usestate</h1>

            <input
                type="text"
                placeholder="Search by name, category or brand"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
            />

            <h2>Products</h2>

            <div className="products">
                {filteredProducts.map((product) => (
                    <div className="product-card" key={product._id}>
                        {product.image && (
                            <img
                                src={`http://localhost:5000${product.image}`}
                                alt={product.name}
                                width="150"
                                height="120"
                                style={{ objectFit: "contain" }}
                            />
                        )}

                        <h3>{product.name}</h3>
                        <p><b>Product ID:</b> {product.productId}</p>
                        <p><b>Category:</b> {product.category}</p>
                        <p><b>Brand:</b> {product.brand}</p>
                        <p><b>Price:</b> ₹{product.price}</p>
                        <p><b>Stock:</b> {product.stock}</p>
                        <p><b>Color:</b> {product.color}</p>
                        <p>{product.description}</p>

                        <button
                            onClick={() => addToCart(product)}
                            disabled={product.stock <= 0}
                        >
                            {product.stock <= 0 ? "Out of Stock" : "Add to Cart"}
                        </button>
                    </div>
                ))}
            </div>

            <h2>My Cart</h2>

            {cart.length === 0 ? (
                <p>Your cart is empty.</p>
            ) : (
                <div className="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            {cart.map((item) => (
                                <tr key={item._id}>
                                    <td>
                                        {item.image && (
                                            <img
                                                src={`http://localhost:5000${item.image}`}
                                                alt={item.name}
                                                width="60"
                                                height="50"
                                                style={{ objectFit: "contain" }}
                                            />
                                        )}
                                    </td>
                                    <td>{item.name}</td>
                                    <td>₹{item.price}</td>
                                    <td>
                                        <button onClick={() => decreaseQty(item._id)}>
                                            -
                                        </button>
                                        {" "}{item.qty}{" "}
                                        <button
                                            onClick={() => increaseQty(item._id)}
                                            disabled={item.qty >= item.stock}
                                        >
                                            +
                                        </button>
                                    </td>
                                    <td>₹{item.price * item.qty}</td>
                                    <td>
                                        <button onClick={() => removeItem(item._id)}>
                                            Remove
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            <h2>Total Amount: ₹{total}</h2>
        </div>
    );
}

export default ShoppingCart;
