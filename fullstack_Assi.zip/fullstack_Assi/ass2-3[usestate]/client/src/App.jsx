import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ShoppingCart from './component/ShoppingCart'
import Admin from './component/Admin'

function App() {
  const [page, setPage] = useState("shop");

  return (

    <div>
            <nav className="main-nav">
                <button onClick={() => setPage("shop")}>
                    Shopping Cart
                </button>

                <button onClick={() => setPage("admin")}>
                    Admin Panel
                </button>
            </nav>

            {page === "shop" ? <ShoppingCart /> : <Admin />}
        </div>
  )
}

export default App
