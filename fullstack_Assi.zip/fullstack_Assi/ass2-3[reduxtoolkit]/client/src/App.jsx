import { useDispatch, useSelector } from "react-redux";
import "./App.css";
import ShoppingCart from "./component/ShoppingCart";
import Admin from "./component/Admin";
import { setPage } from "./store/appSlice";

function App() {
    const dispatch = useDispatch();
    const page = useSelector((state) => state.app.page);

    return (
        <div>
            <nav className="main-nav">
                <button onClick={() => dispatch(setPage("shop"))}>
                    Shopping Cart
                </button>
                <button onClick={() => dispatch(setPage("admin"))}>
                    Admin Panel
                </button>
            </nav>
            {page === "shop" ? <ShoppingCart /> : <Admin />}
        </div>
    );
}

export default App;
