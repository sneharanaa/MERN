import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import API from "../service/app";
import { resetProduct, setProductField } from "../store/adminSlice";

function Admin() {
    const dispatch = useDispatch();
    const product = useSelector((state) => state.admin.product);
    const [image, setImage] = useState(null);

    const handleChange = (e) => {
        dispatch(setProductField({ name: e.target.name, value: e.target.value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        Object.keys(product).forEach((key) => {
            formData.append(key, product[key]);
        });

        if (image) {
            formData.append("image", image);
        }

        try {
            await API.post("/products", formData);
            alert("Product added successfully!");
            dispatch(resetProduct());
            setImage(null);
            e.target.reset();
        } catch (error) {
            alert("Failed to add product");
            console.log(error);
        }
    };

    return (
        <div className="admin-container">
            <h1>Add Product</h1>
            <form className="admin-form" onSubmit={handleSubmit}>
                <input name="productId" type="number" placeholder="Product ID" value={product.productId} onChange={handleChange} required />
                <input name="name" placeholder="Product Name" value={product.name} onChange={handleChange} required />
                <input name="category" placeholder="Category" value={product.category} onChange={handleChange} required />
                <input name="brand" placeholder="Brand" value={product.brand} onChange={handleChange} required />
                <input name="price" type="number" min="0" placeholder="Price" value={product.price} onChange={handleChange} required />
                <input name="stock" type="number" min="0" placeholder="Stock" value={product.stock} onChange={handleChange} required />
                <input name="color" placeholder="Color" value={product.color} onChange={handleChange} required />
                <textarea name="description" placeholder="Description" value={product.description} onChange={handleChange} required />
                <input
                    type="file"
                    name="image"
                    accept="image/*"
                    onChange={(e) => setImage(e.target.files[0])}
                />
                <button type="submit">Add Product</button>
            </form>
        </div>
    );
}

export default Admin;
