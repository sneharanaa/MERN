import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "./cartSlice";
import adminReducer from "./adminSlice";
import appReducer from "./appSlice";

const store = configureStore({
    reducer: {
        cart: cartReducer,
        admin: adminReducer,
        app: appReducer
    }
});

export default store;
