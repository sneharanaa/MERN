import { createSlice } from "@reduxjs/toolkit";

const appSlice = createSlice({
    name: "app",
    initialState: { page: "shop" },
    reducers: {
        setPage: (state, action) => {
            state.page = action.payload;
        }
    }
});

export const { setPage } = appSlice.actions;
export default appSlice.reducer;
