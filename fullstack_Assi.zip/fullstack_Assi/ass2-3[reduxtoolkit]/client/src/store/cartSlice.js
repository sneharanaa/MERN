import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
    name: "cart",
    initialState: {
        products: [],
        items: [],
        search: ""
    },
    reducers: {
        setProducts: (state, action) => {
            state.products = action.payload;
        },
        setSearch: (state, action) => {
            state.search = action.payload;
        },
        addToCart: (state, action) => {
            const product = action.payload;
            const exists = state.items.find((item) => item._id === product._id);

            if (exists) {
                if (exists.qty < exists.stock) {
                    exists.qty += 1;
                }
            } else if (product.stock > 0) {
                state.items.push({ ...product, qty: 1 });
            }
        },
        increaseQty: (state, action) => {
            const item = state.items.find((item) => item._id === action.payload);
            if (item && item.qty < item.stock) {
                item.qty += 1;
            }
        },
        decreaseQty: (state, action) => {
            const item = state.items.find((item) => item._id === action.payload);
            if (item) {
                item.qty -= 1;
                if (item.qty <= 0) {
                    state.items = state.items.filter((cartItem) => cartItem._id !== action.payload);
                }
            }
        },
        removeItem: (state, action) => {
            state.items = state.items.filter((item) => item._id !== action.payload);
        }
    }
});

export const { setProducts, setSearch, addToCart, increaseQty, decreaseQty, removeItem } = cartSlice.actions;
export default cartSlice.reducer;
