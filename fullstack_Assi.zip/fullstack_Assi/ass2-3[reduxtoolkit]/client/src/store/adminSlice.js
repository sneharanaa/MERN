import { createSlice } from "@reduxjs/toolkit";

const initialProduct = {
    productId: "",
    name: "",
    category: "",
    brand: "",
    price: "",
    stock: "",
    color: "",
    description: ""
};

const adminSlice = createSlice({
    name: "admin",
    initialState: { product: initialProduct },
    reducers: {
        setProductField: (state, action) => {
            state.product[action.payload.name] = action.payload.value;
        },
        resetProduct: (state) => {
            state.product = { ...initialProduct };
        }
    }
});

export const { setProductField, resetProduct } = adminSlice.actions;
export default adminSlice.reducer;
