const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
    productId: Number,
    name: String,
    category: String,
    brand: String,
    price: Number,
    stock: Number,
    color: String,
    description: String,
    image: String
});

module.exports = mongoose.model("Product", productSchema);