const mongoose = require("mongoose");

const conndb = async () => {
    try{
        await mongoose.connect("mongodb://localhost:27017/mydb");
        console.log("database connected");
    }catch(error){
        console.log("failed to connect");
    }
}

module.exports = conndb;