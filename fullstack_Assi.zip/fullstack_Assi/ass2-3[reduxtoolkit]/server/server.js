const express = require("express");
const cors = require("cors");
const path = require("path");
const productroute = require("./route/productroute");
const conn = require("./config/db");

const app = express();

conn();

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/api", productroute);

app.listen(5000, () => {
    console.log("Server running on port 5000");
});