import { Link } from "react-router-dom";

function BlogCard({ blog }) {
  return (
    <div className="blog-card">

      <h2>{blog.title}</h2>

      <p>
        {blog.content.length > 150
          ? blog.content.substring(0, 150) + "..."
          : blog.content}
      </p>

      <Link
        to={`/blog/${blog._id}`}
        className="read-more"
      >
        Read More
      </Link>

    </div>
  );
}

export default BlogCard;