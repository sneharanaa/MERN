
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import API from "../service/api";

function BlogDetails() {
    const { id } = useParams();
    const navigate = useNavigate();

    const [blog, setBlog] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    // Fetch single blog
    const fetchBlog = async () => {
        try {
            setLoading(true);
            setError("");

            const response = await API.get(`/blogs/${id}`);
            setBlog(response.data);
        } catch (error) {
            setError(
                error.response?.data?.message || "Failed to load blog"
            );
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchBlog();
    }, [id]);

    // Delete blog
    const handleDelete = async () => {
        const confirmDelete = window.confirm(
            "Are you sure you want to delete this blog?"
        );

        if (!confirmDelete) return;

        try {
            await API.delete(`/blogs/${id}`);

            alert("Blog deleted successfully");
            navigate("/");
        } catch (error) {
            alert(
                error.response?.data?.message || "Failed to delete blog"
            );
        }
    };

    if (loading) {
        return <p className="message">Loading...</p>;
    }

    if (error) {
        return <p className="error">{error}</p>;
    }

    if (!blog) {
        return <p>Blog not found.</p>;
    }

    return (
        <div className="details-container">
            <article className="blog-details">
                <h1>{blog.title}</h1>

                <div className="blog-meta">

                    <span>
                        {blog.createdAt
                            ? new Date(blog.createdAt).toLocaleDateString()
                            : ""}
                    </span>
                </div>

                <div className="blog-content">
                    {blog.content}
                </div>

                <div className="blog-actions">
                    <Link
                        to={`/edit/${blog._id}`}
                        className="edit-btn"
                    >
                        Edit
                    </Link>

                    <button
                        onClick={handleDelete}
                        className="delete-btn"
                    >
                        Delete
                    </button>
                </div>

                <br />

                <Link to="/">Back to Home</Link>
            </article>
        </div>
    );
}

export default BlogDetails;
