
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import BlogCard from "../component/BlogCard";
import { fetchBlogs } from "../features/blogs/blogSlice";

function Home() {
  const dispatch = useDispatch();

  const { blogs, loading, error } = useSelector(
    (state) => state.blogs
  );

  useEffect(() => {
    dispatch(fetchBlogs());
  }, [dispatch]);

  return (
    <div className="container">
      <div className="home-header">
        <h1>All Blogs</h1>
      </div>

      {loading && (
        <p className="message">Loading blogs...</p>
      )}

      {error && (
        <p className="error">{error}</p>
      )}

      {!loading && !error && blogs.length === 0 && (
        <p className="message">No blogs available.</p>
      )}

      <div className="blog-grid">
        {blogs.map((blog) => (
          <BlogCard key={blog._id} blog={blog} />
        ))}
      </div>
    </div>
  );
}

export default Home;
