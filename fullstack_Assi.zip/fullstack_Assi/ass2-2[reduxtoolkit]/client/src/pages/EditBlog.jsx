
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import API from "../service/api";

function EditBlog() {
    const { id } = useParams();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        title: "",
        content: ""
    });

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState("");

    // Fetch existing blog data
    useEffect(() => {
        const fetchBlog = async () => {
            try {
                setLoading(true);
                setError("");

                const response = await API.get(`/blogs/${id}`);
                const blog = response.data;

                setFormData({
                    title: blog.title || "",
                    content: blog.content || ""
                });
            } catch (error) {
                setError(
                    error.response?.data?.message ||
                    "Failed to load blog"
                );
            } finally {
                setLoading(false);
            }
        };

        fetchBlog();
    }, [id]);

    // Handle input changes
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    // Update blog
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.title.trim() || !formData.content.trim()) {
            setError("Title and content are required");
            return;
        }

        try {
            setSaving(true);
            setError("");

            await API.put(`/blogs/${id}`, {
                title: formData.title,
                content: formData.content
            });

            alert("Blog updated successfully");

            navigate(`/blog/${id}`);
        } catch (error) {
            setError(
                error.response?.data?.message ||
                "Failed to update blog"
            );
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return <p className="message">Loading...</p>;
    }

    if (error && !formData.title && !formData.content) {
        return <p className="error">{error}</p>;
    }

    return (
        <div className="form-container">
            <div className="form-box blog-form">
                <h1>Edit Blog</h1>

                {error && <p className="error">{error}</p>}

                <form onSubmit={handleSubmit}>
                    <label>Blog Title</label>

                    <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="Enter blog title"
                        required
                    />

                    <label>Blog Content</label>

                    <textarea
                        name="content"
                        value={formData.content}
                        onChange={handleChange}
                        placeholder="Write your blog..."
                        rows="10"
                        required
                    />

                    <button type="submit" disabled={saving}>
                        {saving ? "Updating..." : "Update Blog"}
                    </button>

                    <button
                        type="button"
                        onClick={() => navigate(`/blog/${id}`)}
                    >
                        Cancel
                    </button>
                </form>
            </div>
        </div>
    );
}

export default EditBlog;
