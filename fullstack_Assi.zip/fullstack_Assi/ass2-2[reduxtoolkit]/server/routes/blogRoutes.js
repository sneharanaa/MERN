
const express = require("express");
const Blog = require("../models/Blog");

const router = express.Router();

// CREATE BLOG
router.post("/", async (req, res) => {
    try {
        const { title, content } = req.body;

        const blog = await Blog.create({
            title,
            content
        });

        res.status(201).json({
            message: "Blog created successfully",
            data: blog
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// GET ALL BLOGS
router.get("/", async (req, res) => {
    try {
        const blogs = await Blog.find().sort({ createdAt: -1 });

        res.status(200).json(blogs);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// GET SINGLE BLOG BY ID
router.get("/:id", async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);

        if (!blog) {
            return res.status(404).json({
                message: "Blog not found"
            });
        }

        res.status(200).json(blog);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// UPDATE BLOG
router.put("/:id", async (req, res) => {
    try {
        const { title, content } = req.body;

        const blog = await Blog.findByIdAndUpdate(
            req.params.id,
            { title, content },
            { new: true, runValidators: true }
        );

        if (!blog) {
            return res.status(404).json({
                message: "Blog not found"
            });
        }

        res.status(200).json({
            message: "Blog updated successfully",
            data: blog
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// DELETE BLOG
router.delete("/:id", async (req, res) => {
    try {
        const blog = await Blog.findByIdAndDelete(req.params.id);

        if (!blog) {
            return res.status(404).json({
                message: "Blog not found"
            });
        }

        res.status(200).json({
            message: "Blog deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

module.exports = router;
