import { useEffect, useState } from "react"; 


const categories = [
  "Food",
  "Shopping",
  "Transport",
  "Entertainment",
  "Medical",
  "Education",
  "Bills",
  "Others"
];

const paymentMethods = [
  "Cash",
  "UPI",
  "Credit Card",
  "Debit Card",
  "Net Banking"
];

function ExpenseForm({
  addExpense,
  updateExpense,
  editExpense,
  cancelEdit
}) {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [date, setDate] = useState("");
  const [payment, setPayment] = useState("Cash");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (editExpense) {
      setTitle(editExpense.title);
      setAmount(editExpense.amount);
      setCategory(editExpense.category);
      setDate(editExpense.date);
      setPayment(editExpense.payment);
      setDescription(editExpense.description || "");
      setError("");
    }
  }, [editExpense]);

  function clearForm() {
    setTitle("");
    setAmount("");
    setCategory("Food");
    setDate("");
    setPayment("Cash");
    setDescription("");
    setError("");
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (title.trim() === "") {
      setError("Expense Title is required.");
      return;
    }

    if (title.trim().length < 3) {
      setError(
        "Expense Title must have at least 3 characters."
      );
      return;
    }

    if (
      amount === "" ||
      Number(amount) <= 0
    ) {
      setError(
        "Amount must be greater than zero."
      );
      return;
    }

    if (!date) {
      setError("Date cannot be empty.");
      return;
    }
    const expense = {
      id: editExpense
        ? editExpense.id
        : Date.now(),
      title: title.trim(),
      amount: Number(amount),
      category: category,
      date: date,
      payment: payment,
      description: description.trim()
    };
    if (editExpense) {
      updateExpense(expense);
    } else {
      addExpense(expense);
    }
    clearForm();
  }
  function handleCancel() {
    clearForm();
    cancelEdit();
  }

  return (
    <div style={{border:"1px solid grey" , width:"1005px" , borderRadius:"20px" , padding:"20px" }}>
      <h2>
        {editExpense
          ? "Edit Expense"
          : "Add Expense"}
      </h2>
      {error && (
        <p className="error">
          {error}
        </p>
      )}

      <form onSubmit={handleSubmit}>
        <div>

          <div>
            <label>
              Expense Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) =>
                setTitle(e.target.value)
              }
              placeholder="Enter expense title"
            />
          </div><br />

          <div>
            <label>
              Amount
            </label>
            <input
              type="number"
              min="0"
              value={amount}
              onChange={(e) =>
                setAmount(e.target.value)
              }
              placeholder="Enter amount"
            />
          </div><br />

          <div>
            <label>
              Category
            </label>
            <select
              value={category}
              onChange={(e) =>
                setCategory(e.target.value)
              }
            >
              {categories.map((item) => (
                <option
                  key={item}
                  value={item}
                >
                  {item}
                </option>
              ))}
            </select>
          </div><br />

          <div>
            <label>
              Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) =>
                setDate(e.target.value)
              }
            />
          </div><br />

          <div>
            <label>
              Payment Method
            </label>
            <select
              value={payment}
              onChange={(e) =>
                setPayment(e.target.value)
              }
            >
              {paymentMethods.map((item) => (
                <option
                  key={item}
                  value={item}
                >
                  {item}
                </option>
              ))}
            </select>
          </div><br />

          <div>
            <label>
              Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) =>
                setDescription(e.target.value)
              }
              placeholder="Optional"
            />
          </div>
        </div><br />

        <button
          className="add-btn"
          type="submit"
        >
          {editExpense
            ? "Update Expense"
            : "Add Expense"}
        </button>
        {editExpense && (
          <button
            className="cancel-btn"
            type="button"
            onClick={handleCancel}
          >
            Cancel
          </button>
        )}
        
      </form>

      
    </div>
    
  );

}


export default ExpenseForm;