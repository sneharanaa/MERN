import { useEffect, useState } from "react";
import ExpenseForm from "./ExpenseForm";
import ExpenseList from "./ExpenseList";
import Reports from "./Reports";
import "bootstrap/dist/css/bootstrap.min.css";
import API from "../services/api";

function ExpenseTracker() {
  const [expenses, setExpenses] = useState([]);
  const [editExpense, setEditExpense] = useState(null);

  useEffect(() => {
    getExpenses();
  }, []);

  async function getExpenses() {
    try {
      const res = await API.get("/expenses");
      setExpenses(res.data);
    } catch (error) {
      console.log(error);
      alert("Unable to load expenses. Check the backend and MongoDB.");
    }
  }

  async function addExpense(expense) {
    try {
      const res = await API.post("/expenses", expense);
      setExpenses((oldExpenses) => [...oldExpenses, res.data]);
    } catch (error) {
      console.log(error);
      alert("Failed to add expense.");
    }
  }

  async function updateExpense(expense) {
    try {
      const res = await API.put(`/expenses/${expense.id}`, expense);
      setExpenses((oldExpenses) =>
        oldExpenses.map((item) => item.id === expense.id ? res.data : item)
      );
      setEditExpense(null);
    } catch (error) {
      console.log(error);
      alert("Failed to update expense.");
    }
  }

  async function deleteExpense(id) {
    const answer = window.confirm("Are you sure you want to delete this expense?");
    if (!answer) return;

    try {
      await API.delete(`/expenses/${id}`);
      setExpenses((oldExpenses) => oldExpenses.filter((item) => item.id !== id));
    } catch (error) {
      console.log(error);
      alert("Failed to delete expense.");
    }
  }

  function editExpenseHandler(expense) {
    setEditExpense(expense);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function cancelEdit() {
    setEditExpense(null);
  }

  const totalAmount = expenses.reduce((sum, expense) => sum + Number(expense.amount), 0);
  const totalTransactions = expenses.length;
  const highestExpense = expenses.length > 0
    ? Math.max(...expenses.map((expense) => Number(expense.amount)))
    : 0;
  const averageExpense = expenses.length > 0 ? totalAmount / expenses.length : 0;

  return (
    <>
      <div style={{textAlign:"center", justifyItems:"center", alignItems:"center", borderRadius:"20px", border:"1px solid grey", width:"1130px"}}>
        <div style={{textAlign:"center"}}>
          <div style={{textAlign:"center"}}>
            <h1>Expense Tracker</h1>
            <p>Manage and track your daily expenses easily</p>
          </div>
          <div style={{textAlign:"center"}}>
            <span>Total Transactions</span><br />
            <h2><strong>{totalTransactions}</strong></h2>
          </div>
        </div>

        <div style={{textAlign:"center", display:"flex", flexWrap:"wrap", gap:"20px", justifyContent:"center"}}>
          <div style={{textAlign:"center", border:"1px solid grey", borderRadius:"20px", padding:"20px", width:"200px"}}>
            <p style={{textAlign:"center"}}>Total Expense</p>
            <h2 style={{textAlign:"center"}}>₹{totalAmount.toFixed(2)}</h2>
          </div>
          <div style={{textAlign:"center", border:"1px solid grey", borderRadius:"20px", padding:"20px", width:"200px"}}>
            <p style={{textAlign:"center"}}>Transactions</p>
            <h2 style={{textAlign:"center"}}>{totalTransactions}</h2>
          </div>
          <div style={{textAlign:"center", border:"1px solid grey", borderRadius:"20px", padding:"20px", width:"200px"}}>
            <p style={{textAlign:"center"}}>Highest Expense</p>
            <h2 style={{textAlign:"center"}}>₹{highestExpense.toFixed(2)}</h2>
          </div>
          <div style={{textAlign:"center", border:"1px solid grey", borderRadius:"20px", padding:"20px", width:"200px"}}>
            <p style={{textAlign:"center"}}>Average Expense</p>
            <h2 style={{textAlign:"center"}}>₹{averageExpense.toFixed(2)}</h2>
          </div>
        </div><br />

        <div style={{textAlign:"center"}}>
          <ExpenseForm addExpense={addExpense} updateExpense={updateExpense} editExpense={editExpense} cancelEdit={cancelEdit} />
        </div><br />
        <div style={{textAlign:"center"}}>
          <ExpenseList expenses={expenses} onEdit={editExpenseHandler} onDelete={deleteExpense} />
        </div><br />
        <div style={{textAlign:"center"}}>
          <Reports expenses={expenses} />
        </div>
        <div style={{textAlign:"center"}}>
          Expense Tracker • Your data is saved in MongoDB
        </div>
      </div>
    </>
  );
}

export default ExpenseTracker;
