
function Reports({ expenses }) {

  const total = expenses.reduce(
    (sum, expense) => sum + Number(expense.amount),
    0
  );

  const highest = expenses.length > 0
    ? Math.max(
        ...expenses.map(
          (expense) => Number(expense.amount)
        )
      )
    : 0;

  const lowest = expenses.length > 0
    ? Math.min(
        ...expenses.map(
          (expense) => Number(expense.amount)
        )
      )
    : 0;

  const average = expenses.length > 0
    ? total / expenses.length
    : 0;


  const categories = [
    "Food",
    "Shopping",
    "Transport",
    "Entertainment",
    "Medical",
    "Education",
    "Bills",
    "Others"
  ];


  const categoryData = categories.map((category) => {

    const amount = expenses
      .filter(
        (expense) => expense.category === category
      )
      .reduce(
        (sum, expense) =>
          sum + Number(expense.amount),
        0
      );

    return {
      category: category,
      amount: amount
    };

  });


  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];


  const monthlyData = months.map(
    (month, index) => {

      const amount = expenses
        .filter((expense) => {

          const date = new Date(
            expense.date + "T00:00:00"
          );

          return date.getMonth() === index;

        })
        .reduce(
          (sum, expense) =>
            sum + Number(expense.amount),
          0
        );

      return {
        month: month,
        amount: amount
      };

    }
  );


  const maxAmount = Math.max(
    ...monthlyData.map(
      (item) => item.amount
    ),
    1
  );


  return (
    <div className="reports">
      <h2>Monthly & Category Reports</h2>
      <div style={{textAlign:"center", display:"flex" , flexWrap:"wrap", gap:"20px", justifyContent :"center"}} className="summary">

        <div style={{textAlign:"center" , border:"1px solid grey" , borderRadius:"20px" , padding:"20px" , width:"200px"}}>
          <h3>Total Expenses</h3>
          <p>₹{total.toFixed(2)}</p>
        </div>

        <div style={{textAlign:"center" , border:"1px solid grey" , borderRadius:"20px" , padding:"20px" , width:"200px"}}>
          <h3>Highest Expense</h3>
          <p>₹{highest.toFixed(2)}</p>
        </div>

        <div style={{textAlign:"center" , border:"1px solid grey" , borderRadius:"20px" , padding:"20px" , width:"200px"}}>
          <h3>Lowest Expense</h3>
          <p>₹{lowest.toFixed(2)}</p>
        </div>

        <div style={{textAlign:"center" , border:"1px solid grey" , borderRadius:"20px" , padding:"20px" , width:"200px"}}>
          <h3>Average Expense</h3>
          <p>₹{average.toFixed(2)}</p>
        </div>

        <div style={{textAlign:"center" , border:"1px solid grey" , borderRadius:"20px" , padding:"20px" , width:"200px"}}>
          <h3>Transactions</h3>
          <p>{expenses.length}</p>
        </div>

      </div><br />

      <div >
        <div style={{border:"1px solid grey" , width:"1005px" , borderRadius:"20px" , padding:"20px"  , justifyItems:"center" , marginLeft:"40px"}} className="report-card">

          <h3>Category-wise Report</h3>

          <table border={1} style={{width:"500px"}}>

            <thead>
              <tr>
                <th>Category</th>
                <th>Total</th>
              </tr>
            </thead>

            <tbody>

              {categoryData.map((item) => (

                <tr key={item.category}>

                  <td>
                    {item.category}
                  </td>

                  <td>
                    ₹{item.amount.toFixed(2)}
                  </td>

                </tr>

              ))}

            </tbody>

          </table>
        </div>

  <div className="report-card">
  <h3>Monthly Expense Bar Chart</h3>

  <div
    className="d-flex align-items-end justify-content-around border-bottom"
    style={{ height: "350px" }}
  >
    {monthlyData.map((item) => {
      const height = (item.amount / maxAmount) * 250;

      return (
        <div
          key={item.month}
          className="d-flex flex-column align-items-center justify-content-end"
        >
          <small>₹{item.amount.toFixed(0)}</small>

          <div
            className="bg-primary rounded-top"
            style={{
              width: "35px",
              height: `${height}px`,
            }}
          ></div>

          <small className="fw-bold mt-2">
            {item.month.substring(0, 3)}
          </small>
        </div>
      );
    })}
  </div>
</div>

      </div>

    </div>
  );
}


export default Reports;