import { useMemo, useState } from "react";


function ExpenseList({
  expenses,
  onEdit,
  onDelete
}) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [payment, setPayment] = useState("All");
  const [month, setMonth] = useState("All");
  const [year, setYear] = useState("All");
  const [sort, setSort] = useState("newest");

  const categories = [
    ...new Set(
      expenses.map((e) => e.category)
    )
  ];

  const payments = [
    ...new Set(
      expenses.map((e) => e.payment)
    )
  ];

  const years = [
    ...new Set(
      expenses.map((e) =>
        e.date.substring(0, 4)
      )
    )
  ];

  const filteredExpenses = useMemo(() => {
    let result = expenses.filter(
      (expense) => {
        const text =
          search.toLowerCase();
        const matchesSearch =
          expense.title
            .toLowerCase()
            .includes(text) ||
          expense.category
            .toLowerCase()
            .includes(text);
        const matchesCategory =
          category === "All" ||
          expense.category === category;
        const matchesPayment =
          payment === "All" ||
          expense.payment === payment;
        const matchesMonth =
          month === "All" ||
          expense.date.substring(5, 7) === month;
        const matchesYear =
          year === "All" ||
          expense.date.substring(0, 4) === year;
        return (
          matchesSearch &&
          matchesCategory &&
          matchesPayment &&
          matchesMonth &&
          matchesYear
        );
      }
    );

    result.sort((a, b) => {
      if (sort === "newest") {
        return (
          new Date(b.date) -
          new Date(a.date)
        );

      }
      if (sort === "oldest") {
        return (
          new Date(a.date) -
          new Date(b.date)
        );
      }
      if (sort === "amountAsc") {

        return a.amount - b.amount;

      }
      if (sort === "amountDesc") {

        return b.amount - a.amount;

      }
      return 0;

    });
    return result;

  }, [
    expenses,
    search,
    category,
    payment,
    month,
    year,
    sort
  ]);


  return (

    <div style={{border:"1px solid grey" , width:"1005px" , borderRadius:"20px" , padding:"20px"  , justifyItems:"center"}} className="list-card">

      <h2>
        Expense List
      </h2>


      <div className="filters">

        <input
          type="text"
          placeholder="Search title or category..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />


        <select
          value={category}
          onChange={(e) =>
            setCategory(e.target.value)
          }
        >

          <option value="All">
            All Categories
          </option>

          {categories.map((item) => (

            <option
              key={item}
              value={item}
            >
              {item}
            </option>

          ))}
        </select>
        <select
          value={payment}
          onChange={(e) =>
            setPayment(e.target.value)
          }
        >
          <option value="All">
            All Payments
          </option>

          {payments.map((item) => (

            <option
              key={item}
              value={item}
            >
              {item}
            </option>

          ))}
        </select>

        <select
          value={month}
          onChange={(e) =>
            setMonth(e.target.value)
          }
        >

          <option value="All">
            All Months
          </option>

          <option value="01">January</option>
          <option value="02">February</option>
          <option value="03">March</option>
          <option value="04">April</option>
          <option value="05">May</option>
          <option value="06">June</option>
          <option value="07">July</option>
          <option value="08">August</option>
          <option value="09">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>

        </select>


        <select
          value={year}
          onChange={(e) =>
            setYear(e.target.value)
          }
        >

          <option value="All">
            All Years
          </option>

          {years.map((item) => (

            <option
              key={item}
              value={item}
            >
              {item}
            </option>

          ))}

        </select>


        <select
          value={sort}
          onChange={(e) =>
            setSort(e.target.value)
          }
        >

          <option value="newest">
            Date - Newest First
          </option>

          <option value="oldest">
            Date - Oldest First
          </option>

          <option value="amountAsc">
            Amount - Low to High
          </option>

          <option value="amountDesc">
            Amount - High to Low
          </option>

        </select>

      </div><br />


      <div className="table-container">

        <table border="1">

          <thead>

            <tr>

              <th>Sr. No.</th>

              <th>Expense Title</th>

              <th>Category</th>

              <th>Amount</th>

              <th>Date</th>

              <th>Payment Method</th>

              <th>Action</th>

            </tr>

          </thead>
          <tbody>

            {filteredExpenses.length === 0 ? (

              <tr>

                <td
                  colSpan="7"
                  className="empty"
                >
                  No expenses found.
                </td>

              </tr>

            ) : (

              filteredExpenses.map(
                (expense, index) => (

                  <tr key={expense.id}>

                    <td>
                      {index + 1}
                    </td>

                    <td>
                      {expense.title}
                    </td>

                    <td>
                      {expense.category}
                    </td>

                    <td>
                      ₹{expense.amount.toFixed(2)}
                    </td>

                    <td>
                      {expense.date}
                    </td>

                    <td>
                      {expense.payment}
                    </td>

                    <td>

                      <button
                        className="edit-btn"
                        onClick={() =>
                          onEdit(expense)
                        }
                      >
                        Edit
                      </button>


                      <button
                        className="delete-btn"
                        onClick={() =>
                          onDelete(expense.id)
                        }
                      >
                        Delete
                      </button>

                    </td>

                  </tr>

                )
              )

            )}

          </tbody>

        </table>

      </div>

    </div>

  );

}


export default ExpenseList;