const express = require("express");
const mongoose = require("mongoose");
const Expense = require("../models/Expense");

const router = express.Router();

function formatExpense(expense) {
    const item = expense.toObject ? expense.toObject() : expense;
    return { ...item, id: item._id.toString() };
}

router.get("/", async (req, res) => {
    try {
        const expenses = await Expense.find().sort({ createdAt: 1 });
        res.json(expenses.map(formatExpense));
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post("/", async (req, res) => {
    try {
        const expense = await Expense.create({
            title: req.body.title,
            amount: Number(req.body.amount),
            category: req.body.category,
            date: req.body.date,
            payment: req.body.payment,
            description: req.body.description || ""
        });
        res.status(201).json(formatExpense(expense));
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

router.put("/:id", async (req, res) => {
    try {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({ message: "Invalid expense ID" });
        }
        const expense = await Expense.findByIdAndUpdate(
            req.params.id,
            {
                title: req.body.title,
                amount: Number(req.body.amount),
                category: req.body.category,
                date: req.body.date,
                payment: req.body.payment,
                description: req.body.description || ""
            },
            { new: true, runValidators: true }
        );
        if (!expense) {
            return res.status(404).json({ message: "Expense not found" });
        }
        res.json(formatExpense(expense));
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

router.delete("/:id", async (req, res) => {
    try {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).json({ message: "Invalid expense ID" });
        }
        const expense = await Expense.findByIdAndDelete(req.params.id);
        if (!expense) {
            return res.status(404).json({ message: "Expense not found" });
        }
        res.json({ message: "Expense deleted successfully" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
