const users = require('../model/user');

//registration
const register = async (req , res) => {
    try {
        
        const {name , email , password , phone , age , gender , dob , course , image} = req.body;

        //check empty field
        if(!name || !email || !password || !phone || !age || !gender || !dob || !course || !image)
        {
            return res.status(400).json({
                message : "all fields are require!"
            });
        }

        //check if email already exists
        const existinguser = await users.findOne({email});
        if(existinguser)
        {
            return res.status(400).json({
                message : "user already exists"
            });
        }

        //create user
        const user = await users.create({
            name , 
            email , 
            password , 
            phone , 
            age , 
            gender , 
            dob , 
            course , 
            image
        });
        res.status(200).json({
            message : "User registerd successfully",
            user : {
                id : user._id ,
                name : user.name ,
                email : user.email , 
                phone : user.phone ,
                age : user.age ,
                gender : user.gender ,
                dob : user.dob ,
                course : user.course ,
                image : user.image
            }
        });

    } catch(error){

        res.status(500).json({
            message : "Registration failed" ,
            error : error.message
        });
    }
}

//login
const loginuser = async (req,res) => {
    try {

        const {email , password} = req.body;
        
        //check empty field
        if(!email || !password)
        {
            return res.status(400).json({
                message : "Email and password are require!"
            });
        }

        //find user
        const user = await users.findOne({email , password});
        if(!user)
        {
            res.status(401).json({
                message : "invalid email and password!"
            });
        }

        res.status(200).json({
            message : "login successfully" ,
            user : {
                id : user._id , 
                name : user.name ,
                email : user.email 
            }
        });

    } catch(error) {
        res.status(500).json({
            message : "login failed" ,
            error : error.message
        });
    }
}

//get users
const getusers = async (req,res) => {
    try {
        const user = await users.find().select("-password");
        res.status(200).json(user);

    } catch(error) {
        res.status(500).json({
            message : "Failed to get students" ,
            error : error.message
        });
    }
}

module.exports = {
    register , 
    loginuser , 
    getusers
};