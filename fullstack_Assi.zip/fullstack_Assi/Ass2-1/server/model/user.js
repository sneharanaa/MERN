const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
    {
        name : {
            type : String ,
            require : true ,
            trim : true
        } ,
        email : {
            type : String ,
            require : true ,
            unique : true ,
            trim : true ,
            lowercase : true
        } ,
        password : {
            type : String ,
            require : true ,
        } , 
        phone : {
            type: String,
            required: true,
            trim: true
        } ,
        age: {
            type: Number,
            required: true,
            min: 1,
            max: 100
        },
        gender: {
            type: String,
            required: true,
            enum: ["Male", "Female", "Other"]
        },
        dob: {
            type: Date,
            required: true
        },
        course: {
            type: String,
            required: true,
            trim: true
        },
        image: {
            type: String,
            default: ""
        }
    }
)

module.exports = mongoose.model("user" , userSchema);