const express = require("express");

const {register , loginuser , getusers} = require('../controller/userController');

const router = express.Router();

//registration
router.post('/register' , register);

//login
router.post('/login' , loginuser);

//get all users
router.get('/getuser' , getusers);

module.exports = router;