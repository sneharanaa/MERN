const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

const connDB = require("./config/db");
const userRoute =   require("./routes/userRoute");

dotenv.config();

//connect mongodb
connDB();

const app = express();

//midddleware
app.use(cors());
app.use(express.json());

//test route
app.get("/" , (req,res) => {
    res.send("server is running");
});

//user route
app.use("/api/users" , userRoute);

//server
const PORT = process.env.PORT || 5000;

app.listen(PORT , () => {
    console.log(`server is running on http://localhost:${PORT}`);
});
