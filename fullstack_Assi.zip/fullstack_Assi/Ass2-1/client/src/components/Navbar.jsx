import React from 'react'
import { Link, useNavigate } from 'react-router-dom';

function Navbar() {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("user");
    navigate("/")
  }

  return (
    <div>
      <nav>
        <Link to={'/users'}>Users</Link>
        {!user && 
          (
            <>
              <div>
                <Link to={'/register'}>Register</Link>   
                <Link to={'/'}>Login</Link>
              </div>
            </>
        )}
        {user && (
          <>
            <button onClick={logout}>Logout</button>
          </>
        )}

      </nav>
    </div>
  )
}

export default Navbar;
