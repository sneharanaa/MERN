import { useState } from 'react'
import {BrowserRouter , Routes , Route} from "react-router-dom"
import  Navbar  from './components/Navbar'
import  Registration  from './pages/Registration'
import  Login  from './pages/Login'
import  Users  from './pages/Users'
import "./App.css";

function App() {
  // const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>
        <Navbar/>
        
        <Routes>
          <Route path='/register' element={<Registration/>}/>
          <Route path='/' element={<Login/>}/>
          <Route path='/users' element={<Users/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
