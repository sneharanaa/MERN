import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Registration() {

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        phone: "",
        age: "",
        gender: "",
        dob: "",
        course: "",
        image: ""
    });

    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {

            const response = await axios.post(
                "http://localhost:5000/api/users/register",
                formData
            );

            alert(response.data.message);

            // Save user in localStorage
            localStorage.setItem(
                "user",
                JSON.stringify(response.data.user)
            );

            // Go to home page
            navigate("/users");

        } catch (error) {

            console.log(error);

            alert(
                error.response?.data?.message ||
                "Registration failed"
            );
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if(!file){
            return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
            setFormData({
                ...formData ,
                image : reader.result
            });
        };
        reader.readAsDataURL(file);
    };

    return (
        <div className="registration-container">

            <h2>Student Registration</h2>

            <form onSubmit={handleSubmit}>

                {/* Name */}
                <div>
                    <label>Name</label>

                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Enter name"
                    />
                </div>


                {/* Email */}
                <div>
                    <label>Email</label>

                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Enter email"
                    />
                </div>


                {/* Password */}
                <div>
                    <label>Password</label>

                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="Enter password"
                    />
                </div>


                {/* Phone */}
                <div>
                    <label>Phone</label>

                    <input
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="Enter phone number"
                    />
                </div>


                {/* Age */}
                <div>
                    <label>Age</label>

                    <input
                        type="number"
                        name="age"
                        value={formData.age}
                        onChange={handleChange}
                        min="1"
                        max="100"
                        placeholder="Enter age"
                    />
                </div>


                {/* Gender */}
                <div>
                    <label>Gender</label>

                    <select
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                    >
                        <option value="">
                            Select Gender
                        </option>

                        <option value="Male">
                            Male
                        </option>

                        <option value="Female">
                            Female
                        </option>

                        <option value="Other">
                            Other
                        </option>
                    </select>
                </div>


                {/* Date of Birth */}
                <div>
                    <label>Date of Birth</label>

                    <input
                        type="date"
                        name="dob"
                        value={formData.dob}
                        onChange={handleChange}
                    />
                </div>


                {/* Course */}
                <div>
                    <label>Course</label>

                    <input
                        type="text"
                        name="course"
                        value={formData.course}
                        onChange={handleChange}
                        placeholder="Enter course"
                    />
                </div>


                {/* Image */}
                <div>
                    <label>Image</label>

                    <input
                        type="file"
                        accept="image/*"
                        name="image"
                        onChange={handleImageChange}
                    />
                </div>
                {/* image preview */}
                {
                    formData.image &&(
                        <div>
                            <p>image : </p>
                        <img 
                            src={formData.image} 
                            alt="preview" 
                            width="150" 
                            height="150" 
                        />
                </div>
                    )
                }
                


                {/* Submit */}
                <button type="submit">
                    Register
                </button>

            </form>

        </div>
    );
}

export default Registration;