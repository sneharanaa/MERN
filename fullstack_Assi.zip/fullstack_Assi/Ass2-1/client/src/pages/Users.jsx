import { useEffect, useState } from "react";
import API from "../service/api";

function Users() {

  const [users, setUsers] = useState([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");

  const getUsers = async () => {

    try {

      const response = await API.get("/getuser");

      setUsers(response.data);

    } catch (error) {

      setError("Failed to load users");

    } finally {

      setLoading(false);

    }
  };

  useEffect(() => {

    getUsers();

  }, []);

  return (
    <div className="page">

      <div className="users-box">

        <h2>Users</h2>

        {loading && (
          <p>Loading users...</p>
        )}

        {error && (
          <p className="error">
            {error}
          </p>
        )}

        {!loading && !error && users.length === 0 && (
          <p>No users found.</p>
        )}

        {!loading && users.length > 0 && (

          <table>

            <thead>

              <tr>
                <th>Name</th>
                <th>Email</th>
              </tr>

            </thead>

            <tbody>

              {users.map((user) => (

                <tr key={user._id}>

                  <td>
                    {user.name}
                  </td>

                  <td>
                    {user.email}
                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        )}

      </div>

    </div>
  );
}

export default Users;